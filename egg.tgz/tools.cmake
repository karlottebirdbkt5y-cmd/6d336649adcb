# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(throughput-bench src/throughput-bench.cpp)
set_property(TARGET throughput-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(throughput-bench lionss pthread)

add_executable(in-source-guard src/in-source-guard.cpp)
set_property(TARGET in-source-guard PROPERTY CXX_STANDARD 11)
target_link_libraries(in-source-guard lionss pthread)

add_executable(strip-check src/strip-check.cpp)
set_property(TARGET strip-check PROPERTY CXX_STANDARD 11)
target_link_libraries(strip-check lionss pthread)

add_executable(cli-tests src/cli-tests.cpp)
set_property(TARGET cli-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(cli-tests lionss pthread)

add_executable(portable-binary src/portable-binary.cpp)
set_property(TARGET portable-binary PROPERTY CXX_STANDARD 11)
target_link_libraries(portable-binary lionss pthread)

add_executable(p99-latency src/p99-latency.cpp)
set_property(TARGET p99-latency PROPERTY CXX_STANDARD 11)
target_link_libraries(p99-latency lionss pthread)

add_executable(cross-toolchain src/cross-toolchain.cpp)
set_property(TARGET cross-toolchain PROPERTY CXX_STANDARD 11)
target_link_libraries(cross-toolchain lionss pthread)

add_executable(mkdocs-build src/mkdocs-build.cpp)
set_property(TARGET mkdocs-build PROPERTY CXX_STANDARD 11)
target_link_libraries(mkdocs-build lionss pthread)

add_executable(clang-17 src/clang-17.cpp)
set_property(TARGET clang-17 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-17 lionss pthread)

add_executable(ios-arm64 src/ios-arm64.cpp)
set_property(TARGET ios-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(ios-arm64 lionss pthread)

add_executable(configure-defaults src/configure-defaults.cpp)
set_property(TARGET configure-defaults PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-defaults lionss pthread)

add_executable(build-relwithdebinfo src/build-relwithdebinfo.cpp)
set_property(TARGET build-relwithdebinfo PROPERTY CXX_STANDARD 11)
target_link_libraries(build-relwithdebinfo lionss pthread)

add_executable(timezone-tests src/timezone-tests.cpp)
set_property(TARGET timezone-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(timezone-tests lionss pthread)

add_executable(scoop-manifest src/scoop-manifest.cpp)
set_property(TARGET scoop-manifest PROPERTY CXX_STANDARD 11)
target_link_libraries(scoop-manifest lionss pthread)

add_executable(cosign-verify src/cosign-verify.cpp)
set_property(TARGET cosign-verify PROPERTY CXX_STANDARD 11)
target_link_libraries(cosign-verify lionss pthread)

add_executable(misra-check src/misra-check.cpp)
set_property(TARGET misra-check PROPERTY CXX_STANDARD 11)
target_link_libraries(misra-check lionss pthread)

add_executable(mocked-tests src/mocked-tests.cpp)
set_property(TARGET mocked-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(mocked-tests lionss pthread)

add_executable(macos-x86-64 src/macos-x86-64.cpp)
set_property(TARGET macos-x86-64 PROPERTY CXX_STANDARD 11)
target_link_libraries(macos-x86-64 lionss pthread)

add_executable(timeout-tests src/timeout-tests.cpp)
set_property(TARGET timeout-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(timeout-tests lionss pthread)

add_executable(warm-cache-bench src/warm-cache-bench.cpp)
set_property(TARGET warm-cache-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(warm-cache-bench lionss pthread)

add_executable(smoke src/smoke.cpp)
set_property(TARGET smoke PROPERTY CXX_STANDARD 11)
target_link_libraries(smoke lionss pthread)

add_executable(portage-ebuild src/portage-ebuild.cpp)
set_property(TARGET portage-ebuild PROPERTY CXX_STANDARD 11)
target_link_libraries(portage-ebuild lionss pthread)

add_executable(shadow-call-stack src/shadow-call-stack.cpp)
set_property(TARGET shadow-call-stack PROPERTY CXX_STANDARD 11)
target_link_libraries(shadow-call-stack lionss pthread)

add_executable(optional-features src/optional-features.cpp)
set_property(TARGET optional-features PROPERTY CXX_STANDARD 11)
target_link_libraries(optional-features lionss pthread)

add_executable(build-header-only src/build-header-only.cpp)
set_property(TARGET build-header-only PROPERTY CXX_STANDARD 11)
target_link_libraries(build-header-only lionss pthread)

add_executable(valgrind-drd src/valgrind-drd.cpp)
set_property(TARGET valgrind-drd PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-drd lionss pthread)

add_executable(asan-ubsan src/asan-ubsan.cpp)
set_property(TARGET asan-ubsan PROPERTY CXX_STANDARD 11)
target_link_libraries(asan-ubsan lionss pthread)

add_executable(dependency-graph src/dependency-graph.cpp)
set_property(TARGET dependency-graph PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-graph lionss pthread)

add_executable(gdb-pretty-print src/gdb-pretty-print.cpp)
set_property(TARGET gdb-pretty-print PROPERTY CXX_STANDARD 11)
target_link_libraries(gdb-pretty-print lionss pthread)

add_executable(atomics-bench src/atomics-bench.cpp)
set_property(TARGET atomics-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(atomics-bench lionss pthread)

