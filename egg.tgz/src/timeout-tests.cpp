// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("timeout tests\n", stdout);
  return lionss_run_workload("timeout-tests");
}
