// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("macos x86 64"); }
int main(){
  announce();
  return lionss_run_workload("macos-x86-64");
}
