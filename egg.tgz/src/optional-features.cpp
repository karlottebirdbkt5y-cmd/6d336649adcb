// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("optional features"); }
int main(){
  announce();
  return lionss_run_workload("optional-features");
}
