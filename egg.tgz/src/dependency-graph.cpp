// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("dependency graph\n", stdout);
  return lionss_run_workload("dependency-graph");
}
