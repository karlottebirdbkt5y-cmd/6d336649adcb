// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("clang 17"); }
int main(){
  announce();
  return lionss_run_workload("clang-17");
}
